import java.util.Scanner;

public class Principal{
	public static Scanner sc = new Scanner(System.in);
	public static void main(String args[]){
	String help = "\tshow (informações)\n"+
			  "\tinit_x (tamanho da sala)\n"+
			  "\treservar_id_fone_cadeira\n"+
			  "\tcancelar_id\n"+
			  "\tsair";
		Cinema ci = new Cinema(new Cliente[0]);
		while(true){
			System.out.print("(help para obter ajuda)Digite o comando: ");
			String comando = sc.nextLine();
			if (comando.equals("help")){
				System.out.println(help);
				continue;
			}
			if (comando.equals("sair")){
				break;
			}
			String v[] = comando.split(" ");
			
			switch(v[0]){
				case "show":
						System.out.println(ci);
					break;
				
				case "init":
					if(v.length!=2){
						System.out.println("Comando invalido.");
						break;
					}
					int a = Integer.parseInt(v[1]);
					ci.setClientes(new Cliente[a]);
					System.out.println(ci);
					break;
					
				case "reservar":
					if(v.length!=4){
						System.out.println("Comando invalido.");
						break;
					}
					String b = v[1];
					int c = Integer.parseInt(v[2]);
					int d = Integer.parseInt(v[3]);
					Cliente cli = new Cliente(b,c);
					System.out.println(ci.reservar(cli,d-1));
					
					break;
				
				case "cancelar":
					if(v.length!=2){
						System.out.println("Comando invalido.");
						break;
					}
					b = v[1];
					System.out.println(ci.cancelar(b));
					break;
				
				default:
					System.out.println("Comando invalido.");
			}
		}
	}
}
