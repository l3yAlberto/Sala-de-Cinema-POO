public class Cinema{
	private Cliente clientes[];
	
	public Cinema(Cliente[] clientes){
		this.clientes = clientes;
	}
	public Cliente[] getClientes(){
		return this.clientes;
	}
	public void setClientes(Cliente[] clientes){
		this.clientes = clientes;
	}
	public String reservar(Cliente cliente, int indice){
		if (this.clientes.length==0){
			return "Use o comando init_x>0";
		}
		if ((indice>=this.clientes.length)||(indice<0)){
			return "A cadeira não existe";
		}
		for(int i=0;i<this.clientes.length;i++){
			if ((this.clientes[i]!=null)&&(this.clientes[i].getId().equals(cliente.getId()))){
				return "failure: cliente ja esta no cinema";
			}
		}
		if((indice<clientes.length)&&(this.clientes[indice]==null)){
			this.clientes[indice] = cliente;
			return "Success";
		}
		return "failure: cadeira ja esta ocupada";
	}
	public String cancelar(String str){
		if (this.clientes.length==0){
			return "Use o comando init";
		}
		for(int i=0;i<this.clientes.length;i++){
			if((clientes[i]!=null)&&(clientes[i].getId().equals(str))){
				this.clientes[i] = null;
				return "success";
			}
		}
	return "failure: cliente nao esta no cinema";
	}
	public String toString(){
		String str = "[";
		for(int i=0;i<this.clientes.length;i++){
			if (clientes[i]==null){
				str += " -";
			}
			else{
				str += " "+clientes[i];
			}
		}
		str += " ]";
		return str;
	}
}
