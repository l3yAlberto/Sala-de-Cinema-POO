public class Cliente{
	private String id;
	private int telefone;
	
	public Cliente(String id,int telefone){
		this.id = id;
		this.telefone = telefone;
	}
	
	public String getId(){
		return this.id;
	}
	public void setId(String id){
		this.id = id;
	}
	public int getTelefone(){
		return this.telefone;
	}
	public void setTelefone(int telefone){
		this.telefone = telefone;
	}
	public String toString(){
		String st = this.id+":"+this.telefone;
		return st;
	}
}
